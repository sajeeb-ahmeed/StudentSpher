import express from 'express';
import session from 'express-session';
import SQLiteStoreFactory from 'connect-sqlite3';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcrypt';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import cors from 'cors';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

const SQLiteStore = SQLiteStoreFactory(session);
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: './' }),
  secret: process.env.SESSION_SECRET || 'change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

app.use('/uploads', express.static(uploadsDir));
app.use(express.static('public'));

sqlite3.verbose();
const db = new sqlite3.Database('database.sqlite');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    phone TEXT,
    password_hash TEXT,
    bio TEXT,
    avatar TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS submissions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    filename TEXT,
    originalname TEXT,
    notes TEXT,
    score INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);
});

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Not authenticated' });
  next();
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + '-' + file.originalname.replace(/\s+/g, '_'));
  }
});
const upload = multer({ storage });

app.post('/api/register', async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
    const hash = await bcrypt.hash(password, 10);
    db.run(`INSERT INTO users(name, email, phone, password_hash) VALUES(?,?,?,?)`,
      [name, email.toLowerCase(), phone || '', hash],
      function(err) {
        if (err) {
          if (String(err).includes('UNIQUE')) return res.status(400).json({ error: 'Email already registered' });
          return res.status(500).json({ error: 'DB error' });
        }
        req.session.user = { id: this.lastID, name, email: email.toLowerCase() };
        res.json({ ok: true, user: req.session.user });
      });
  } catch (e) {
    res.status(500).json({ error: 'Internal error' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
  db.get(`SELECT * FROM users WHERE email=?`, [email.toLowerCase()], async (err, row) => {
    if (err || !row) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, row.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    req.session.user = { id: row.id, name: row.name, email: row.email, avatar: row.avatar };
    res.json({ ok: true, user: req.session.user });
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

app.get('/api/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

app.put('/api/profile', requireAuth, (req, res) => {
  const { name, bio, phone, avatar } = req.body;
  db.run(`UPDATE users SET name=?, bio=?, phone=?, avatar=? WHERE id=?`,
    [name || '', bio || '', phone || '', avatar || '', req.session.user.id],
    function(err) {
      if (err) return res.status(500).json({ error: 'DB error' });
      req.session.user.name = name || req.session.user.name;
      req.session.user.avatar = avatar || req.session.user.avatar;
      res.json({ ok: true });
    });
});

app.post('/api/task/submit', requireAuth, upload.single('file'), (req, res) => {
  const { notes } = req.body;
  if (!req.file) return res.status(400).json({ error: 'File required' });
  db.run(`INSERT INTO submissions(user_id, filename, originalname, notes) VALUES(?,?,?,?)`,
    [req.session.user.id, req.file.filename, req.file.originalname, notes || ''],
    function(err) {
      if (err) return res.status(500).json({ error: 'DB error' });
      res.json({ ok: true, submissionId: this.lastID, fileUrl: '/uploads/' + req.file.filename });
    });
});

app.get('/api/my/submissions', requireAuth, (req, res) => {
  db.all(`SELECT * FROM submissions WHERE user_id=? ORDER BY created_at DESC`, [req.session.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ submissions: rows });
  });
});

// New: user's scores endpoint (only for authenticated user)
app.get('/api/myscores', requireAuth, (req, res) => {
  const uid = req.session.user.id;
  db.all(`SELECT id, originalname as task_name, score, created_at FROM submissions WHERE user_id=? ORDER BY created_at ASC`, [uid], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    const total = rows.reduce((s, r) => s + (r.score || 0), 0);
    res.json({ scores: rows, total });
  });
});

// Leaderboard: sum of scores per user (total score)
app.get('/api/leaderboard', (req, res) => {
  const q = `
    SELECT u.id as user_id, u.name, u.avatar, 
           COALESCE(SUM(s.score),0) as total_score, 
           COUNT(s.id) as total_submissions
    FROM users u
    LEFT JOIN submissions s ON s.user_id = u.id
    GROUP BY u.id
    ORDER BY total_score DESC, total_submissions DESC, u.name ASC
    LIMIT 200
  `;
  db.all(q, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ leaderboard: rows });
  });
});

// Admin: set score for a submission
app.post('/api/admin/score', (req, res) => {
  const { adminCode, submissionId, score } = req.body;
  if (!adminCode || adminCode !== (process.env.ADMIN_CODE || 'super-admin-123')) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  const s = Math.max(0, Math.min(100, Number(score)||0));
  db.run(`UPDATE submissions SET score=? WHERE id=?`, [s, submissionId], function(err) {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ ok: true, updated: this.changes });
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log('Server running on http://localhost:' + PORT);
});
