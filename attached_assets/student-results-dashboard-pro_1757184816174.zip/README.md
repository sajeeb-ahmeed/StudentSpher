# Student Results Dashboard - Pro (Local ZIP)

## What's included
- Node.js + Express backend with SQLite
- Authentication, profile, file upload (assignments)
- Leaderboard sums total scores across assignments
- `/api/myscores` endpoint for student to view individual scores + total
- Professional frontend pages with TailwindCSS and simple animations

## To run locally
1. Install Node.js (LTS).
2. Extract this project.
3. Create a `.env` file with:
   ```
   SESSION_SECRET=your-secret
   ADMIN_CODE=your-admin-code
   PORT=3000
   ```
4. Run:
   ```
   npm install
   npm start
   ```
5. Open http://localhost:3000

## Admin scoring
Use the admin API to grade submissions:
```bash
curl -X POST http://localhost:3000/api/admin/score \
 -H "Content-Type: application/json" \
 -d '{"adminCode":"YOUR_ADMIN_CODE","submissionId":1,"score":95}'
```
