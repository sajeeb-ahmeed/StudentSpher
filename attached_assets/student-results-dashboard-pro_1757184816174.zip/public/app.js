// Shared frontend helper and API calls
async function api(path, opts={}) {
  const res = await fetch(path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(opts.headers||{}) },
    ...opts,
  });
  if (!res.ok) {
    let errText = 'Request failed';
    try { const j = await res.json(); errText = j.error || errText; } catch(_) {}
    throw new Error(errText);
  }
  return res.json();
}

function alertBox(msg, ok=true) {
  return `<div class="p-3 rounded-lg ${ok?'bg-emerald-50 border border-emerald-200':'bg-red-50 border border-red-200'}">${msg}</div>`;
}

function bindRegister() {
  const form = document.getElementById('registerForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    try {
      await api('/api/register', { method: 'POST', body: JSON.stringify(body) });
      location.href = '/dashboard.html';
    } catch(e) { alert(e.message); }
  });
}

function bindLogin() {
  const form = document.getElementById('loginForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form).entries());
    try {
      await api('/api/login', { method: 'POST', body: JSON.stringify(body) });
      location.href = '/dashboard.html';
    } catch(e) { alert(e.message); }
  });
}

async function loadDashboard() {
  const meBox = document.getElementById('meBox');
  try {
    const me = await api('/api/me');
    if (!me.user) { location.href = '/login.html'; return; }
    meBox.innerHTML = `
      <div class="flex items-center gap-4">
        <img src="${me.user.avatar || 'https://placehold.co/88x88'}" class="w-20 h-20 rounded-full object-cover" />
        <div>
          <div class="text-xl font-semibold">${me.user.name}</div>
          <div class="text-sm text-slate-500">${me.user.email}</div>
          <div class="text-sm mt-2">${me.user.bio || ''}</div>
        </div>
      </div>
    `;

    const form = document.getElementById('profileForm');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = Object.fromEntries(new FormData(form).entries());
      try {
        await api('/api/profile', { method: 'PUT', body: JSON.stringify(body) });
        alert('Profile updated');
        location.reload();
      } catch(e) { alert(e.message); }
    });

    const mine = await api('/api/my/submissions');
    const list = document.getElementById('mySubmissions');
    list.innerHTML = mine.submissions.map(s => `
      <div class="bg-white p-3 rounded-lg shadow flex items-center justify-between">
        <div>
          <div class="font-semibold">${s.originalname}</div>
          <div class="text-sm text-slate-500">Score: ${s.score ?? 0} • ${new Date(s.created_at).toLocaleString()}</div>
        </div>
        <div><a class="text-indigo-600" href="${'/uploads/' + s.filename}" target="_blank">Download</a></div>
      </div>
    `).join('') || '<div class="text-sm text-slate-500">No submissions yet.</div>';
  } catch(e) {
    console.error(e);
    location.href = '/login.html';
  }
}

function bindSubmit() {
  const form = document.getElementById('submitForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    try {
      const res = await fetch('/api/task/submit', { method: 'POST', body: fd, credentials: 'include' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');
      document.getElementById('submitResult').innerHTML = alertBox('Uploaded ✔️');
      form.reset();
    } catch(e) {
      document.getElementById('submitResult').innerHTML = alertBox(e.message, false);
    }
  });
}
